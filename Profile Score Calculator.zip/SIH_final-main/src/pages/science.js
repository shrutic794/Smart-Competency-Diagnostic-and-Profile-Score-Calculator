import React from 'react';

export const Science = () => {
  const iframeUrl = 'https://cdn.soft8soft.com/AROAJSY2GOEHMOFUVPIOE:67ae7a429f/applications/Screw_Gauge/index.html';

  return (
    <iframe
      src={iframeUrl}
      title="Hack-IT V-Labs"
      style={{ width: '100%', height: '100vh', border: 'none' }}
    />
  );
};
